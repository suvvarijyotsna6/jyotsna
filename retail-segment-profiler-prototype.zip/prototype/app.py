"""
Retail Multi-Segment Profiler & High-Value Customer Classifier
Flask prototype app.

Run with:  python3 app.py
Then open: http://127.0.0.1:5000
"""
import json
import joblib
import numpy as np
import pandas as pd
from flask import Flask, render_template, request

app = Flask(__name__)

with open("artifacts.json") as f:
    ARTIFACTS = json.load(f)

rf = joblib.load("model_rf.joblib")
kmeans = joblib.load("model_kmeans.joblib")
cluster_scaler = joblib.load("scaler_cluster.joblib")
CLUSTER_TO_PERSONA = ARTIFACTS["cluster_to_persona"]

PERSONA_STRATEGY = {
    "Premium Target Shoppers": "Highest priority: premium product lines, loyalty tiers, early access, personalised outreach.",
    "Cautious High Earners": "High income, low spend — run win-back campaigns, exclusive previews and trust-building offers.",
    "Aspirational Spenders": "High engagement relative to income — offer financing/instalments and trend-led bundles.",
    "Budget-Conscious Shoppers": "Largest, mainstream segment — everyday value promos, loyalty points, cross-sell bundles.",
    "Balanced Mainstream Shoppers": "Lowest income/spend — use low-cost, broad-reach channels rather than personalised campaigns.",
}


@app.route("/")
def dashboard():
    return render_template(
        "dashboard.html",
        a=ARTIFACTS,
        personas=ARTIFACTS["persona_summary"],
        strategy=PERSONA_STRATEGY,
    )


@app.route("/predict", methods=["GET", "POST"])
def predict():
    result = None
    form_values = {"age": 30, "gender": "Female", "income": 60, "spending": ""}

    if request.method == "POST":
        age = float(request.form.get("age"))
        gender = request.form.get("gender")
        income = float(request.form.get("income"))
        spending_raw = request.form.get("spending", "").strip()

        form_values = {"age": age, "gender": gender, "income": income, "spending": spending_raw}

        gender_code = 1 if gender == "Female" else 0
        X_new = pd.DataFrame(
            [[age, gender_code, income]], columns=["Age", "Gender_Code", "Annual Income (k$)"]
        )
        proba = float(rf.predict_proba(X_new)[0, 1])
        pred = int(proba >= 0.5)

        persona = None
        if spending_raw != "":
            spending = float(spending_raw)
            X_cluster_df = pd.DataFrame(
                [[income, spending]], columns=["Annual Income (k$)", "Spending Score (1-100)"]
            )
            X_cluster = cluster_scaler.transform(X_cluster_df)
            cluster_id = int(kmeans.predict(X_cluster)[0])
            persona = CLUSTER_TO_PERSONA[str(cluster_id)]

        result = {
            "high_value": bool(pred),
            "probability": round(proba * 100, 1),
            "persona": persona,
            "strategy": PERSONA_STRATEGY.get(persona) if persona else None,
        }

    return render_template("predict.html", result=result, form_values=form_values)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
