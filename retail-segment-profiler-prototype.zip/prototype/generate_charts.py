import json
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({"figure.facecolor": "white", "axes.facecolor": "white"})

df = pd.read_csv("customers_scored.csv")
with open("artifacts.json") as f:
    A = json.load(f)

OUT = "static/charts"
COLORS = ["#2c5f7c", "#e8834a", "#5fa8a0", "#c65d7b", "#8a9a5b"]

def save(fig, name):
    fig.tight_layout()
    fig.savefig(f"{OUT}/{name}.png", dpi=130)
    plt.close(fig)

# 1. Gender distribution
fig, ax = plt.subplots(figsize=(5, 3.5))
counts = df["Gender"].value_counts()
ax.bar(counts.index, counts.values, color=["#2c5f7c", "#e8834a"])
for i, v in enumerate(counts.values):
    ax.text(i, v + 2, str(v), ha="center", fontweight="bold")
ax.set_title("Customer Gender Distribution")
ax.set_ylabel("Number of Customers")
save(fig, "gender")

# 2. Age distribution
fig, ax = plt.subplots(figsize=(5, 3.5))
ax.hist(df["Age"], bins=10, color="#2c5f7c", edgecolor="white")
ax.axvline(df["Age"].mean(), color="#e8834a", linestyle="--", label=f"Mean = {df['Age'].mean():.1f}")
ax.set_title("Distribution of Customer Age")
ax.set_xlabel("Age (years)")
ax.set_ylabel("Number of Customers")
ax.legend()
save(fig, "age")

# 3. Income distribution
fig, ax = plt.subplots(figsize=(5, 3.5))
ax.hist(df["Annual Income (k$)"], bins=10, color="#5fa8a0", edgecolor="white")
ax.axvline(df["Annual Income (k$)"].mean(), color="#e8834a", linestyle="--", label=f"Mean = {df['Annual Income (k$)'].mean():.1f}k$")
ax.set_title("Distribution of Annual Income")
ax.set_xlabel("Annual Income (k$)")
ax.set_ylabel("Number of Customers")
ax.legend()
save(fig, "income")

# 4. Spending score distribution
fig, ax = plt.subplots(figsize=(5, 3.5))
ax.hist(df["Spending Score (1-100)"], bins=10, color="#c65d7b", edgecolor="white")
ax.axvline(df["Spending Score (1-100)"].mean(), color="#2c5f7c", linestyle="--", label=f"Mean = {df['Spending Score (1-100)'].mean():.1f}")
ax.set_title("Distribution of Spending Score")
ax.set_xlabel("Spending Score (1-100)")
ax.set_ylabel("Number of Customers")
ax.legend()
save(fig, "spending")

# 5. Elbow method
fig, ax = plt.subplots(figsize=(5, 3.5))
ax.plot(A["elbow"]["k"], A["elbow"]["inertia"], marker="o", color="#2c5f7c")
ax.axvline(5, color="#e8834a", linestyle="--", label="Chosen K = 5")
ax.set_title("Elbow Method for Optimal K")
ax.set_xlabel("Number of Clusters (K)")
ax.set_ylabel("Inertia (Within-Cluster SSE)")
ax.legend()
save(fig, "elbow")

# 6. Silhouette scores
fig, ax = plt.subplots(figsize=(5, 3.5))
ax.plot(A["elbow"]["k"], A["elbow"]["silhouette"], marker="o", color="#5fa8a0")
ax.axvline(5, color="#e8834a", linestyle="--", label="Chosen K = 5")
ax.set_title("Silhouette Score vs Number of Clusters")
ax.set_xlabel("Number of Clusters (K)")
ax.set_ylabel("Average Silhouette Score")
ax.legend()
save(fig, "silhouette")

# 7. Cluster scatter
fig, ax = plt.subplots(figsize=(6, 4.5))
persona_map = A["cluster_to_persona"]
for i, cid in enumerate(sorted(df["Cluster"].unique())):
    sub = df[df["Cluster"] == cid]
    ax.scatter(sub["Annual Income (k$)"], sub["Spending Score (1-100)"],
               color=COLORS[i % len(COLORS)], label=persona_map[str(cid)], s=25, alpha=0.85)
ax.set_title("Customer Segments — K-Means Clustering (K=5)")
ax.set_xlabel("Annual Income (k$)")
ax.set_ylabel("Spending Score (1-100)")
ax.legend(fontsize=8, loc="center left", bbox_to_anchor=(1.0, 0.5))
save(fig, "segments")

# 8. Persona size pie
fig, ax = plt.subplots(figsize=(5, 5))
ps = pd.DataFrame(A["persona_summary"])
ax.pie(ps["Customers"], labels=ps["Persona"], autopct="%1.1f%%",
       colors=COLORS[:len(ps)], textprops={"fontsize": 8})
ax.set_title("Customer Segment Size Distribution")
save(fig, "persona_pie")

# 9. Feature importance
fig, ax = plt.subplots(figsize=(5, 3))
fi = A["feature_importance"]
names = list(fi.keys())
vals = list(fi.values())
order = np.argsort(vals)
ax.barh([names[i] for i in order], [vals[i] for i in order], color="#2c5f7c")
ax.set_title("Feature Importance — Random Forest")
ax.set_xlabel("Relative Importance")
save(fig, "feature_importance")

# 10. Confusion matrix
fig, ax = plt.subplots(figsize=(4.5, 4))
cm = np.array(A["confusion_matrix"])
im = ax.imshow(cm, cmap="Blues")
for i in range(2):
    for j in range(2):
        ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                color="white" if cm[i, j] > cm.max() / 2 else "black", fontsize=14, fontweight="bold")
ax.set_xticks([0, 1]); ax.set_xticklabels(["Not High-Value", "High-Value"])
ax.set_yticks([0, 1]); ax.set_yticklabels(["Not High-Value", "High-Value"])
ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
ax.set_title("Confusion Matrix — Random Forest")
save(fig, "confusion")

# 11. Model comparison
fig, ax = plt.subplots(figsize=(6, 3.5))
labels = ["accuracy", "precision", "recall", "f1"]
rf_vals = [A["rf_metrics"][k] for k in labels]
lr_vals = [A["lr_metrics"][k] for k in labels]
x = np.arange(len(labels))
w = 0.35
ax.bar(x - w/2, rf_vals, w, label="Random Forest", color="#2c5f7c")
ax.bar(x + w/2, lr_vals, w, label="Logistic Regression", color="#a9c6d8")
ax.set_xticks(x); ax.set_xticklabels(labels)
ax.set_ylim(0, 1)
ax.set_title("Model Comparison: Random Forest vs Logistic Regression")
ax.legend()
save(fig, "model_comparison")

# 12. High-value concentration by persona
fig, ax = plt.subplots(figsize=(6, 3.5))
hv = A["hv_by_persona"]
order = sorted(hv.items(), key=lambda kv: -kv[1])
ax.bar([k for k, v in order], [v for k, v in order], color="#e8834a")
ax.set_xticklabels([k for k, v in order], rotation=20, ha="right", fontsize=8)
ax.set_ylabel("% Classified as High-Value")
ax.set_title("High-Value Customer Concentration by Persona")
save(fig, "hv_by_persona")

print("Charts generated.")
