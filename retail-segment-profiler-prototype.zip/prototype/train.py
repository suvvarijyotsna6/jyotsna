"""
Retail Multi-Segment Profiler & High-Value Customer Classifier
Training pipeline — reproduces the methodology from the internship report
on the actual Mall_Customers.csv dataset, and saves model artifacts for
the Flask prototype app.
"""
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, confusion_matrix, silhouette_score
)

RANDOM_STATE = 42

# ---------------------------------------------------------------
# 1. Load & quality-check data
# ---------------------------------------------------------------
df = pd.read_csv("Mall_Customers.csv")
quality = {
    "shape": df.shape,
    "missing": int(df.isnull().sum().sum()),
    "duplicates": int(df.duplicated().sum()),
}

# ---------------------------------------------------------------
# 2. K-Means segmentation on standardised Income + Spending Score
# ---------------------------------------------------------------
cluster_features = df[["Annual Income (k$)", "Spending Score (1-100)"]]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(cluster_features)

inertia, sil_scores = [], []
for k in range(2, 11):
    km = KMeans(n_clusters=k, random_state=RANDOM_STATE, n_init=10)
    labels = km.fit_predict(X_scaled)
    inertia.append(km.inertia_)
    sil_scores.append(silhouette_score(X_scaled, labels))

K_FINAL = 5
kmeans = KMeans(n_clusters=K_FINAL, random_state=RANDOM_STATE, n_init=10)
df["Cluster"] = kmeans.fit_predict(X_scaled)
final_silhouette = silhouette_score(X_scaled, df["Cluster"])

# Persona naming: rank clusters by (income, spending) to match report's logic
cluster_stats = df.groupby("Cluster").agg(
    n=("CustomerID", "count"),
    avg_income=("Annual Income (k$)", "mean"),
    avg_spending=("Spending Score (1-100)", "mean"),
    avg_age=("Age", "mean"),
    female_share=("Gender", lambda s: (s == "Female").mean() * 100),
)

def classify_persona(row, income_mean, spending_mean):
    high_income = row["avg_income"] >= income_mean
    high_spend = row["avg_spending"] >= spending_mean
    if high_income and high_spend:
        return "Premium Target Shoppers"
    if high_income and not high_spend:
        return "Cautious High Earners"
    if not high_income and high_spend:
        return "Aspirational Spenders"
    if not high_income and not high_spend:
        return "Balanced Mainstream Shoppers"
    return "Budget-Conscious Shoppers"

income_mean = cluster_stats["avg_income"].mean()
spending_mean = cluster_stats["avg_spending"].mean()
# The "middle" / largest cluster (closest to overall mean on both axes) = Budget-Conscious
overall_income_mean = df["Annual Income (k$)"].mean()
overall_spending_mean = df["Spending Score (1-100)"].mean()
cluster_stats["dist_to_center"] = np.sqrt(
    (cluster_stats["avg_income"] - overall_income_mean) ** 2
    + (cluster_stats["avg_spending"] - overall_spending_mean) ** 2
)
budget_cluster = cluster_stats["dist_to_center"].idxmin()

persona_names = {}
for cid, row in cluster_stats.iterrows():
    if cid == budget_cluster:
        persona_names[cid] = "Budget-Conscious Shoppers"
    else:
        persona_names[cid] = classify_persona(row, income_mean, spending_mean)

# Ensure uniqueness in the (rare) collision case
seen = {}
for cid, name in persona_names.items():
    seen.setdefault(name, []).append(cid)
for name, cids in seen.items():
    if len(cids) > 1:
        for i, cid in enumerate(cids):
            persona_names[cid] = f"{name} {i+1}" if i else name

df["Persona"] = df["Cluster"].map(persona_names)

persona_summary = (
    df.groupby("Persona")
    .agg(
        Customers=("CustomerID", "count"),
        Avg_Age=("Age", "mean"),
        Avg_Income=("Annual Income (k$)", "mean"),
        Avg_Spending=("Spending Score (1-100)", "mean"),
        Female_Share=("Gender", lambda s: (s == "Female").mean() * 100),
    )
    .round(1)
    .sort_values("Avg_Income", ascending=False)
    .reset_index()
)

cluster_to_persona = persona_names

# ---------------------------------------------------------------
# 3. Engineer High-Value Customer label (top 30% composite score)
# ---------------------------------------------------------------
value_scaler = MinMaxScaler()
df[["Income_Norm", "Spending_Norm"]] = value_scaler.fit_transform(
    df[["Annual Income (k$)", "Spending Score (1-100)"]]
)
df["Value_Score"] = 0.5 * df["Income_Norm"] + 0.5 * df["Spending_Norm"]
threshold = df["Value_Score"].quantile(0.70)
df["High_Value"] = (df["Value_Score"] >= threshold).astype(int)

# ---------------------------------------------------------------
# 4. Train classifiers on demographic + income features only
#    (no spending score -> avoids leakage, mirrors "new customer" scenario)
# ---------------------------------------------------------------
df["Gender_Code"] = df["Gender"].map({"Male": 0, "Female": 1})
features = ["Age", "Gender_Code", "Annual Income (k$)"]
X = df[features]
y = df["High_Value"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=RANDOM_STATE, stratify=y
)

rf = RandomForestClassifier(
    n_estimators=300, max_depth=6, class_weight="balanced", random_state=RANDOM_STATE
)
rf.fit(X_train, y_train)

lr = LogisticRegression(class_weight="balanced", max_iter=1000, random_state=RANDOM_STATE)
lr.fit(X_train, y_train)

rf_pred = rf.predict(X_test)
rf_prob = rf.predict_proba(X_test)[:, 1]
lr_pred = lr.predict(X_test)
lr_prob = lr.predict_proba(X_test)[:, 1]

def metrics_for(y_true, y_pred, y_prob=None):
    m = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
    }
    if y_prob is not None:
        m["roc_auc"] = roc_auc_score(y_true, y_prob)
    return {k: round(v, 3) for k, v in m.items()}

rf_metrics = metrics_for(y_test, rf_pred, rf_prob)
lr_metrics = metrics_for(y_test, lr_pred, lr_prob)
cm = confusion_matrix(y_test, rf_pred).tolist()

feature_importance = dict(zip(features, [round(v, 4) for v in rf.feature_importances_]))

# High-value concentration by persona
hv_by_persona = (
    df.groupby("Persona")["High_Value"].mean().mul(100).round(1).to_dict()
)

# ---------------------------------------------------------------
# 5. Persist everything the Flask app needs
# ---------------------------------------------------------------
joblib.dump(rf, "model_rf.joblib")
joblib.dump(lr, "model_lr.joblib")
joblib.dump(scaler, "scaler_cluster.joblib")
joblib.dump(kmeans, "model_kmeans.joblib")

artifacts = {
    "quality": quality,
    "elbow": {"k": list(range(2, 11)), "inertia": inertia, "silhouette": sil_scores},
    "final_silhouette": round(final_silhouette, 3),
    "cluster_to_persona": {str(k): v for k, v in cluster_to_persona.items()},
    "persona_summary": persona_summary.to_dict(orient="records"),
    "high_value_count": int(df["High_Value"].sum()),
    "high_value_pct": round(df["High_Value"].mean() * 100, 1),
    "value_threshold": round(threshold, 4),
    "train_size": len(X_train),
    "test_size": len(X_test),
    "rf_metrics": rf_metrics,
    "lr_metrics": lr_metrics,
    "confusion_matrix": cm,
    "feature_importance": feature_importance,
    "hv_by_persona": hv_by_persona,
    "dataset_stats": {
        "n": len(df),
        "age_min": int(df["Age"].min()), "age_mean": round(df["Age"].mean(), 1), "age_max": int(df["Age"].max()),
        "income_min": int(df["Annual Income (k$)"].min()), "income_mean": round(df["Annual Income (k$)"].mean(), 1), "income_max": int(df["Annual Income (k$)"].max()),
        "spend_min": int(df["Spending Score (1-100)"].min()), "spend_mean": round(df["Spending Score (1-100)"].mean(), 1), "spend_max": int(df["Spending Score (1-100)"].max()),
        "female_pct": round((df["Gender"] == "Female").mean() * 100, 1),
        "male_pct": round((df["Gender"] == "Male").mean() * 100, 1),
    },
}

with open("artifacts.json", "w") as f:
    json.dump(artifacts, f, indent=2)

df.to_csv("customers_scored.csv", index=False)

print("Training complete.")
print(json.dumps({
    "n_customers": len(df),
    "final_silhouette": artifacts["final_silhouette"],
    "high_value_count": artifacts["high_value_count"],
    "rf_metrics": rf_metrics,
    "lr_metrics": lr_metrics,
    "persona_summary": artifacts["persona_summary"],
}, indent=2))
